// Copyright (c) 2026 Manabu Nakazawa. Licensed under the MIT license. See LICENSE in the project root for license information.

import GitHubTrendingRSSKit
import PathKit
import Stencil
import XCTest

final class FeedFileCreatorTests: XCTestCase {
    private let environment = Environment(
        loader: FileSystemLoader(paths: [Path(Const.resourcesRootURL.path)])
    )
    private let information = SiteSourceMaker.Information(
        pageTitle: "page title",
        author: "spring water",
        rssHomeURL: "rss home url",
        googleAnalyticsTrackingCode: "141421356",
        gitHubRepositoryURL: "github repository url"
    )
    private var tempDir: URL!

    override func setUp() async throws {
        try await super.setUp()
        try await DocslothManager.shared.setup()
        tempDir = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
    }

    override func tearDown() async throws {
        try? FileManager.default.removeItem(at: tempDir)
        try await super.tearDown()
    }

    func testCreateRSSFilePaths() async throws {
        let maker = SiteSourceMaker(environment: environment, information: information)
        let creator = FeedFileCreator(outputDirectory: tempDir, siteGenerator: maker)
        let link = LanguageTrendingLink(
            displayName: "All Languages", href: Const.gitHubTopTrendingURL.path
        )

        let urlUnspecified = try await creator.createRSSFile(
            repositories: [],
            languageTrendingLink: link,
            period: .daily,
            spokenLanguage: .unspecified,
            supportedEmojis: []
        )
        XCTAssertEqual(urlUnspecified.path, tempDir.appendingPathComponent("daily/all.xml").path)
        XCTAssertTrue(FileManager.default.fileExists(atPath: urlUnspecified.path))

        let urlEn = try await creator.createRSSFile(
            repositories: [],
            languageTrendingLink: link,
            period: .daily,
            spokenLanguage: .en,
            supportedEmojis: []
        )
        XCTAssertEqual(urlEn.path, tempDir.appendingPathComponent("en/daily/all.xml").path)
        XCTAssertTrue(FileManager.default.fileExists(atPath: urlEn.path))
    }

    func testCreateDeveloperRSSFile() async throws {
        let maker = SiteSourceMaker(environment: environment, information: information)
        let creator = FeedFileCreator(outputDirectory: tempDir, siteGenerator: maker)
        let link = LanguageTrendingLink(displayName: "Swift", href: "/trending/swift")

        let dev = Developer(
            username: "testuser",
            displayName: "Test User",
            avatarURL: nil,
            popularRepository: nil
        )

        let fileURL = try await creator.createDeveloperRSSFile(
            developers: [dev],
            languageTrendingLink: link,
            period: .daily,
            supportedEmojis: []
        )

        XCTAssertEqual(fileURL.path, tempDir.appendingPathComponent("developers/daily/swift.xml").path)
        XCTAssertTrue(FileManager.default.fileExists(atPath: fileURL.path))
    }

    func testCreateFeedManifestFile() throws {
        let maker = SiteSourceMaker(environment: environment, information: information)
        let creator = FeedFileCreator(outputDirectory: tempDir, siteGenerator: maker)
        let links = [
            LanguageTrendingLink(displayName: "All Languages", href: Const.gitHubTopTrendingURL.path),
            LanguageTrendingLink(displayName: "Swift", href: "/trending/swift"),
        ]

        let fileURL = try creator.createFeedManifestFile(languageLinks: links)

        XCTAssertEqual(fileURL.path, tempDir.appendingPathComponent("feed-manifest.json").path)
        let data = try Data(contentsOf: fileURL)
        let manifest = try JSONDecoder().decode(FeedManifest.self, from: data)
        XCTAssertEqual(manifest.languages.map(\.slug), ["all", "swift"])
        XCTAssertEqual(manifest.languages[0].displayName, "All Languages")
        XCTAssertEqual(manifest.languages[1].feeds.daily, "daily/swift.xml")
    }

    func testFeedManifestUsesStableEnglishDate() {
        let date = Date(timeIntervalSince1970: 0)
        let manifest = FeedManifest(languageTrendingLinks: [], date: date)

        XCTAssertEqual(manifest.generatedAt, "1970-01-01T00:00:00Z")
        XCTAssertEqual(manifest.latestBuildDate, "1 January, 1970")
    }

    func testCopyAssetsDirectory() throws {
        let maker = SiteSourceMaker(environment: environment, information: information)
        let creator = FeedFileCreator(outputDirectory: tempDir, siteGenerator: maker)

        try creator.copyAssetsDirectory()

        let copiedAssetsDir = tempDir.appendingPathComponent("assets")
        XCTAssertTrue(FileManager.default.fileExists(atPath: copiedAssetsDir.path))
        XCTAssertTrue(
            FileManager.default.fileExists(
                atPath: copiedAssetsDir.appendingPathComponent("icons/linkedin.png").path
            )
        )
        XCTAssertTrue(
            FileManager.default.fileExists(
                atPath: copiedAssetsDir.appendingPathComponent("icons/orcid.png").path
            )
        )
    }
}
