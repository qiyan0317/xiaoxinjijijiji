import Foundation
import XCTest
@testable import GitHubTrendingRSSKit

public struct MockDownloadManagerError: Error {}

final class GitHubGraphQLManagerTests: XCTestCase {
    func testBuildBatchQuery() {
        let manager = GitHubGraphQLManager(downloadManager: DownloadManager(), apiToken: "dummy")
        let query = manager.buildBatchQuery(for: [
            (owner: "facebook", name: "react"),
            (owner: "vuejs", name: "vue"),
        ])

        let expected = """
        query GetMultipleRepos {
          repo_0: repository(owner: "facebook", name: "react") {
            openGraphImageUrl
            usesCustomOpenGraphImage
            homepageUrl
            id
            stargazerCount
            forkCount
          }
          repo_1: repository(owner: "vuejs", name: "vue") {
            openGraphImageUrl
            usesCustomOpenGraphImage
            homepageUrl
            id
            stargazerCount
            forkCount
          }
        }
        """
        XCTAssertEqual(
            query.trimmingCharacters(in: .whitespacesAndNewlines),
            expected.trimmingCharacters(in: .whitespacesAndNewlines)
        )
    }

    func testDecodeBatchQueryResponse() throws {
        let data = TestResources.getData(ofFileName: "api.github.com_graphql_batch_response.json")
        let response = try JSONDecoder().decode(
            GraphQLResponse<[String: RepositoryNode?]>.self, from: data
        )
        XCTAssertNil(response.errors)

        let repos = try XCTUnwrap(response.data)
        XCTAssertEqual(repos.count, 2)

        let repo0Optional = try XCTUnwrap(repos["repo_0"])
        let repo0 = try XCTUnwrap(repo0Optional)
        XCTAssertEqual(
            repo0.openGraphImageUrl.absoluteString,
            "https://opengraph.githubassets.com/dbdb7c9a03dabaa2e52463f68846ac5ea6830d3f326e266518b92f9bc0237e8b/swiftlang/swift"
        )
        XCTAssertFalse(repo0.usesCustomOpenGraphImage)
        XCTAssertEqual(repo0.homepageUrl?.absoluteString, "https://swift.org")

        let repo1Optional = try XCTUnwrap(repos["repo_1"])
        let repo1 = try XCTUnwrap(repo1Optional)
        XCTAssertEqual(
            repo1.openGraphImageUrl.absoluteString,
            "https://opengraph.githubassets.com/4a95d64df8f4beb813af3dca2b07b851592c6a28adc4075e03a4d73a1167561c/microsoft/vscode"
        )
        XCTAssertFalse(repo1.usesCustomOpenGraphImage)
        XCTAssertNil(repo1.homepageUrl)
    }

    func testDecodeRepositoryNodeWithVariousHomepageUrlFormats() throws {
        let json = """
        {
            "data": {
                "repo_empty": {
                    "openGraphImageUrl": "https://example.com/image.png",
                    "usesCustomOpenGraphImage": false,
                    "homepageUrl": "",
                    "id": "1"
                },
                "repo_whitespace": {
                    "openGraphImageUrl": "https://example.com/image.png",
                    "usesCustomOpenGraphImage": false,
                    "homepageUrl": "   ",
                    "id": "2"
                },
                "repo_no_scheme": {
                    "openGraphImageUrl": "https://example.com/image.png",
                    "usesCustomOpenGraphImage": false,
                    "homepageUrl": "openseo.so",
                    "id": "3"
                },
                "repo_full_url": {
                    "openGraphImageUrl": "https://example.com/image.png",
                    "usesCustomOpenGraphImage": false,
                    "homepageUrl": "https://openseo.so",
                    "id": "4"
                },
                "repo_null": {
                    "openGraphImageUrl": "https://example.com/image.png",
                    "usesCustomOpenGraphImage": false,
                    "homepageUrl": null,
                    "id": "5"
                }
            }
        }
        """.data(using: .utf8)!

        let response = try JSONDecoder().decode(
            GraphQLResponse<[String: RepositoryNode?]>.self, from: json
        )
        let repos = try XCTUnwrap(response.data)

        XCTAssertNil(repos["repo_empty"]??.homepageUrl)
        XCTAssertNil(repos["repo_whitespace"]??.homepageUrl)
        XCTAssertEqual(repos["repo_no_scheme"]??.homepageUrl?.absoluteString, "https://openseo.so")
        XCTAssertEqual(repos["repo_full_url"]??.homepageUrl?.absoluteString, "https://openseo.so")
        XCTAssertNil(repos["repo_null"]??.homepageUrl)
    }

    func testBuildBatchUserQuery() {
        let manager = GitHubGraphQLManager(downloadManager: DownloadManager(), apiToken: "dummy")
        let query = manager.buildBatchUserQuery(usernames: ["Astro-Han", "lalalune"])
        XCTAssertTrue(query.contains("user_0: user(login: \"Astro-Han\")"))
        XCTAssertTrue(query.contains("user_1: user(login: \"lalalune\")"))
        XCTAssertTrue(query.contains("email"))
        XCTAssertTrue(query.contains("following"))
        XCTAssertTrue(query.contains("name"))
        XCTAssertFalse(query.contains("organizations"))
        XCTAssertTrue(query.contains("pinnedItems(first: 6, types: [REPOSITORY])"))
        XCTAssertTrue(query.contains("popularRepositories: repositories("))
        XCTAssertTrue(query.contains("ownerAffiliations: OWNER"))
        XCTAssertTrue(query.contains("privacy: PUBLIC"))
        XCTAssertTrue(query.contains("isFork: false"))
        XCTAssertTrue(query.contains("orderBy: {field: STARGAZERS, direction: DESC}"))
    }

    func testDecodeDeveloperNode() throws {
        let json = """
        {
            "bio": "Building stuff",
            "company": "Acme Inc.",
            "location": "Tokyo",
            "email": "dev@example.com",
            "followers": { "totalCount": 100 },
            "following": { "totalCount": 20 },
            "repositories": { "totalCount": 20 },
            "websiteUrl": "https://example.com",
            "twitterUsername": "acme_dev",
            "socialAccounts": {
                "nodes": [
                    { "provider": "BLUESKY", "url": "https://bsky.app/profile/sample.bsky.social", "displayName": "sample.bsky.social" },
                    { "provider": "YOUTUBE", "url": "https://youtube.com/@sample_user", "displayName": "@sample_user" }
                ]
            },
            "pinnedItems": {
                "nodes": [
                    {
                        "name": "cool-project",
                        "url": "https://github.com/acme/cool-project",
                        "description": "A very cool project",
                        "stargazerCount": 50,
                        "forkCount": 12
                    }
                ]
            },
            "popularRepositories": {
                "nodes": [
                    {
                        "name": "popular-project",
                        "url": "https://github.com/acme/popular-project",
                        "description": "A popular project",
                        "stargazerCount": 500,
                        "forkCount": 34
                    }
                ]
            }
        }
        """.data(using: .utf8)!

        let node = try JSONDecoder().decode(DeveloperNode.self, from: json)
        XCTAssertEqual(node.bio, "Building stuff")
        XCTAssertEqual(node.company, "Acme Inc.")
        XCTAssertEqual(node.location, "Tokyo")
        XCTAssertEqual(node.email, "dev@example.com")
        XCTAssertEqual(node.followers?.totalCount, 100)
        XCTAssertEqual(node.following?.totalCount, 20)
        XCTAssertEqual(node.repositories?.totalCount, 20)
        XCTAssertEqual(node.websiteUrl?.absoluteString, "https://example.com")
        XCTAssertEqual(node.twitterUsername, "acme_dev")
        XCTAssertEqual(node.socialAccounts?.nodes?.count, 2)
        XCTAssertEqual(node.socialAccounts?.nodes?.first?.provider, "BLUESKY")
        XCTAssertEqual(
            node.socialAccounts?.nodes?.first?.url.absoluteString,
            "https://bsky.app/profile/sample.bsky.social"
        )
        XCTAssertEqual(node.pinnedItems?.nodes?.count, 1)
        XCTAssertEqual(node.pinnedItems?.nodes?.first?.name, "cool-project")
        XCTAssertEqual(node.pinnedItems?.nodes?.first?.stargazerCount, 50)
        XCTAssertEqual(node.pinnedItems?.nodes?.first?.forkCount, 12)
        XCTAssertEqual(node.popularRepositories?.nodes?.count, 1)
        XCTAssertEqual(node.popularRepositories?.nodes?.first?.name, "popular-project")
        XCTAssertEqual(node.popularRepositories?.nodes?.first?.stargazerCount, 500)
        XCTAssertEqual(node.popularRepositories?.nodes?.first?.forkCount, 34)
    }

    func testDecodeDeveloperNodeWithVariousWebsiteUrlFormats() throws {
        let jsonEmpty = """
        { "websiteUrl": "" }
        """.data(using: .utf8)!
        let nodeEmpty = try JSONDecoder().decode(DeveloperNode.self, from: jsonEmpty)
        XCTAssertNil(nodeEmpty.websiteUrl)

        let jsonNoScheme = """
        { "websiteUrl": "dev.example.com" }
        """.data(using: .utf8)!
        let nodeNoScheme = try JSONDecoder().decode(DeveloperNode.self, from: jsonNoScheme)
        XCTAssertEqual(nodeNoScheme.websiteUrl?.absoluteString, "https://dev.example.com")

        let jsonNull = """
        { "websiteUrl": null }
        """.data(using: .utf8)!
        let nodeNull = try JSONDecoder().decode(DeveloperNode.self, from: jsonNull)
        XCTAssertNil(nodeNull.websiteUrl)
    }

    func testDecodeGraphQLPartialResponseWithErrors() throws {
        let json = """
        {
            "data": {
                "user_0": {
                    "bio": "Valid user",
                    "company": "Valid Corp"
                },
                "user_1": null
            },
            "errors": [
                {
                    "message": "Could not resolve to a User with the login of 'invalid-user'.",
                    "type": "NOT_FOUND"
                }
            ]
        }
        """.data(using: .utf8)!

        let response = try JSONDecoder().decode(
            GraphQLResponse<[String: DeveloperNode?]>.self, from: json
        )
        XCTAssertNotNil(response.data)
        XCTAssertEqual(response.errors?.count, 1)

        let data = try XCTUnwrap(response.data)
        let user0 = try XCTUnwrap(data["user_0"] ?? nil)
        XCTAssertEqual(user0.bio, "Valid user")
        XCTAssertNil(data["user_1"] ?? nil)
    }
}
