// Copyright (c) 2018 Manabu Nakazawa. Licensed under the MIT license. See LICENSE in the project root for license information.

import Foundation

public class Const {
    public static let bundleIdentifier = "io.github.mshibanami.GitHubTrendingRSS"

    public static let rssHomeURL = URL(string: "https://mshibanami.github.io/GitHubTrendingRSS")!
    public static let gitHubAPIBaseURL = URL(string: "https://api.github.com")!
    public static let gitHubAPIEmojisURL = URL(string: "\(gitHubAPIBaseURL)/emojis")!
    public static let gitHubTopTrendingURL = URL(string: "\(gitHubBaseURL)/trending")!
    public static let gitHubBaseURL = URL(string: "https://github.com")!
    public static let gitHubRepositoryURL = URL(
        string: "https://github.com/mshibanami/GitHubTrendingRSS"
    )!
    public static let pageTitle = "GitHub Trending RSS"
    public static let author = "Manabu Nakazawa"

    public static let outputDirectoryName = "output"
    public static let outputDirectory = URL(fileURLWithPath: FileManager.default.currentDirectoryPath)
        .appendingPathComponent(outputDirectoryName)

    public static var resourcesRootURL: URL {
        guard let resourcesURL = Bundle.module.url(forResource: "Resources", withExtension: nil) else {
            fatalError("Resources folder not found")
        }
        return resourcesURL
    }

    public static let googleAnalyticsTrackingCode = "UA-46019833-3"

    public private(set) nonisolated(unsafe) static var githubToken: String!

    public static let popularLanguages = [
        "all",
        "applescript",
        "c",
        "c#",
        "c++",
        "common-lisp",
        "css",
        "dart",
        "dockerfile",
        "emacs-lisp",
        "f#",
        "go",
        "haskell",
        "haxe",
        "html",
        "java",
        "javascript",
        "jupyter-notebook",
        "kotlin",
        "lua",
        "objective-c",
        "perl",
        "php",
        "powershell",
        "python",
        "r",
        "ruby",
        "rust",
        "scala",
        "shell",
        "svelte",
        "svg",
        "swift",
        "tex",
        "typescript",
        "xml",
        "xslt",
    ]

    public static func setup(githubToken: String) {
        self.githubToken = githubToken
    }
}
