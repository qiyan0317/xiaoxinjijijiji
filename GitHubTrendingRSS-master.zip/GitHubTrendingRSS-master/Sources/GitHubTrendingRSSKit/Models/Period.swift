// Copyright (c) 2018 Manabu Nakazawa. Licensed under the MIT license. See LICENSE in the project root for license information.

import Foundation

public enum Period: String, CaseIterable, Sendable {
    case daily
    case weekly
    case monthly
}
