// Copyright (c) 2026 Manabu Nakazawa. Licensed under the MIT license. See LICENSE in the project root for license information.

import Foundation

public struct DeveloperNode: Decodable, Sendable {
    public struct TotalCountContainer: Decodable, Sendable {
        public let totalCount: Int

        public init(totalCount: Int) {
            self.totalCount = totalCount
        }
    }

    public struct PinnedItemNode: Decodable, Sendable {
        public let name: String
        public let url: URL
        public let description: String?
        public let stargazerCount: Int?
        public let forkCount: Int?

        public init(
            name: String, url: URL, description: String?, stargazerCount: Int?, forkCount: Int? = nil
        ) {
            self.name = name
            self.url = url
            self.description = description
            self.stargazerCount = stargazerCount
            self.forkCount = forkCount
        }
    }

    public struct PinnedItemsContainer: Decodable, Sendable {
        public let nodes: [PinnedItemNode]?

        public init(nodes: [PinnedItemNode]?) {
            self.nodes = nodes
        }
    }

    public struct PopularRepositoryNode: Decodable, Sendable {
        public let name: String
        public let url: URL
        public let description: String?
        public let stargazerCount: Int?
        public let forkCount: Int?

        public init(
            name: String, url: URL, description: String?, stargazerCount: Int?, forkCount: Int? = nil
        ) {
            self.name = name
            self.url = url
            self.description = description
            self.stargazerCount = stargazerCount
            self.forkCount = forkCount
        }
    }

    public struct PopularRepositoriesContainer: Decodable, Sendable {
        public let nodes: [PopularRepositoryNode]?

        public init(nodes: [PopularRepositoryNode]?) {
            self.nodes = nodes
        }
    }

    public let bio: String?
    public let company: String?
    public let location: String?
    public let email: String?
    public let followers: TotalCountContainer?
    public let following: TotalCountContainer?
    public let repositories: TotalCountContainer?
    public let websiteUrl: URL?
    public let twitterUsername: String?
    public let socialAccounts: SocialAccountsContainer?
    public let pinnedItems: PinnedItemsContainer?
    public let popularRepositories: PopularRepositoriesContainer?

    enum CodingKeys: String, CodingKey {
        case bio
        case company
        case location
        case email
        case followers
        case following
        case repositories
        case websiteUrl
        case twitterUsername
        case socialAccounts
        case pinnedItems
        case popularRepositories
    }

    public init(
        bio: String? = nil,
        company: String? = nil,
        location: String? = nil,
        email: String? = nil,
        followers: TotalCountContainer? = nil,
        following: TotalCountContainer? = nil,
        repositories: TotalCountContainer? = nil,
        websiteUrl: URL? = nil,
        twitterUsername: String? = nil,
        socialAccounts: SocialAccountsContainer? = nil,
        pinnedItems: PinnedItemsContainer? = nil,
        popularRepositories: PopularRepositoriesContainer? = nil
    ) {
        self.bio = bio
        self.company = company
        self.location = location
        self.email = email
        self.followers = followers
        self.following = following
        self.repositories = repositories
        self.websiteUrl = websiteUrl
        self.twitterUsername = twitterUsername
        self.socialAccounts = socialAccounts
        self.pinnedItems = pinnedItems
        self.popularRepositories = popularRepositories
    }

    public init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        bio = try? container.decode(String.self, forKey: .bio)
        company = try? container.decode(String.self, forKey: .company)
        location = try? container.decode(String.self, forKey: .location)
        email = try? container.decode(String.self, forKey: .email)
        followers = try? container.decode(TotalCountContainer.self, forKey: .followers)
        following = try? container.decode(TotalCountContainer.self, forKey: .following)
        repositories = try? container.decode(TotalCountContainer.self, forKey: .repositories)
        twitterUsername = try? container.decode(String.self, forKey: .twitterUsername)
        socialAccounts = try? container.decode(SocialAccountsContainer.self, forKey: .socialAccounts)
        pinnedItems = try? container.decode(PinnedItemsContainer.self, forKey: .pinnedItems)
        popularRepositories = try? container.decode(PopularRepositoriesContainer.self, forKey: .popularRepositories)
        websiteUrl = URL(
            sanitizedURLString: try? container.decode(String.self, forKey: .websiteUrl)
        )
    }
}

public struct SocialAccountNode: Decodable, Sendable {
    public let provider: String
    public let url: URL
    public let displayName: String

    public init(provider: String, url: URL, displayName: String) {
        self.provider = provider
        self.url = url
        self.displayName = displayName
    }
}

public struct SocialAccountsContainer: Decodable, Sendable {
    public let nodes: [SocialAccountNode]?

    public init(nodes: [SocialAccountNode]?) {
        self.nodes = nodes
    }
}
