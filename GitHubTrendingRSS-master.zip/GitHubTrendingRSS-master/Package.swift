// swift-tools-version:6.2
// Copyright (c) 2018 Manabu Nakazawa. Licensed under the MIT license. See LICENSE in the project root for license information.

import PackageDescription

let package = Package(
    name: "GitHubTrendingRSS",
    platforms: [
        .macOS(.v13),
    ],
    dependencies: [
        .package(url: "https://github.com/hartbit/Yaap", from: "1.0.0"),
        .package(url: "https://github.com/mshibanami/Docsloth.git", from: "1.1.0"),
        .package(url: "https://github.com/scinfu/SwiftSoup", from: "2.3.2"),
        .package(url: "https://github.com/stencilproject/Stencil", from: "0.14.1"),
        .package(url: "https://github.com/apple/swift-algorithms", from: "1.2.0"),
    ],
    targets: [
        .executableTarget(
            name: "GitHubTrendingRSS",
            dependencies: [
                "GitHubTrendingRSSKit",
                "Yaap",
            ]
        ),
        .target(
            name: "GitHubTrendingRSSKit",
            dependencies: [
                .product(name: "DocslothMarkdownItGFMCJKFriendly", package: "Docsloth"),
                .product(name: "DocslothAsciidoctor", package: "Docsloth"),
                "Stencil",
                "SwiftSoup",
                .product(name: "Algorithms", package: "swift-algorithms"),
            ],
            resources: [
                .copy("Resources"),
            ]
        ),
        .testTarget(
            name: "GitHubTrendingRSSTests",
            dependencies: [
                "GitHubTrendingRSSKit",
            ],
            resources: [
                .copy("TestResources"),
            ]
        ),
    ],
    swiftLanguageModes: [.v6]
)
